#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
爬取 B 站用户空间视频列表中的所有视频链接，并自动翻页。
目标页面: https://space.bilibili.com/3546693593205098/upload/video
"""

import os
import re
import sys
import time
from urllib.parse import urljoin

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
    ElementClickInterceptedException,
    StaleElementReferenceException,
)

# ============== 配置 ==============
TARGET_URL = "https://space.bilibili.com/3546693593205098/upload/video"
OUTPUT_FILE = "bilibili_video_links.txt"
PAGE_LOAD_TIMEOUT = 30
IMPLICIT_WAIT = 10
# 视频链接选择器（按优先级尝试）
VIDEO_LINK_SELECTORS = [
    "#submit-video-list .list-list .small-item a.cover",
    "#submit-video-list .list-list .small-item a.title",
    "#submit-video-list a[href*='/video/BV']",
    ".video-list a[href*='/video/BV']",
    "a[href*='/video/BV']",
]
# 下一页按钮选择器（CSS + XPATH 混合尝试）
NEXT_PAGE_STRATEGIES = [
    # strategy: (by, locator, is_clickable_check)
    (By.CSS_SELECTOR, ".be-pager-next:not(.be-pager-disabled)", True),
    (By.CSS_SELECTOR, ".be-pager-next", False),  # 如果没有disabled类，靠JS判断
    (By.XPATH, "//li[contains(@class,'be-pager-next') and not(contains(@class,'be-pager-disabled'))]", True),
    (By.XPATH, "//button[contains(text(),'下一页')]", True),
    (By.XPATH, "//span[contains(text(),'下一页')]/parent::li[not(contains(@class,'disabled'))]", True),
]
# 视频列表容器，用于判断页面是否加载完成
LIST_CONTAINER_SELECTOR = "#submit-video-list .list-list"
# 最大翻页数，防止意外死循环（设为0则不限制）
MAX_PAGES = 0
# 每页最短等待时间（秒）
MIN_WAIT_PER_PAGE = 2
# 是否保存每页 HTML 用于调试
DEBUG_SAVE_HTML = False
DEBUG_DIR = "debug_html"


def create_driver():
    """创建并配置 Chrome WebDriver。"""
    options = Options()
    # 如果需要无头模式，取消下面这行的注释
    # options.add_argument("--headless=new")
    options.add_argument("--start-maximized")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    )
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    # 尝试自动寻找 chromedriver；如果失败，尝试用 Service 指定常见路径
    driver = None
    try:
        driver = webdriver.Chrome(options=options)
    except Exception as e1:
        print(f"直接启动 Chrome 失败: {e1}")
        # 尝试常见路径
        common_paths = [
            "/usr/local/bin/chromedriver",
            "/opt/homebrew/bin/chromedriver",
            "/usr/bin/chromedriver",
        ]
        for p in common_paths:
            if os.path.exists(p):
                print(f"尝试使用 chromedriver: {p}")
                try:
                    driver = webdriver.Chrome(service=Service(p), options=options)
                    break
                except Exception as e2:
                    print(f"  失败: {e2}")
        if driver is None:
            raise RuntimeError(
                "无法启动 ChromeDriver。请确保已安装 chromedriver，\n"
                "或使用: brew install chromedriver"
            )

    driver.set_page_load_timeout(PAGE_LOAD_TIMEOUT)
    driver.implicitly_wait(IMPLICIT_WAIT)
    return driver


def normalize_video_url(href: str) -> str | None:
    """将各种形式的视频链接统一为 https://www.bilibili.com/video/BVxxx 形式。"""
    if not href:
        return None
    # 去掉 query string
    href = href.split("?")[0].split("#")[0]
    # 补全协议和域名
    if href.startswith("/"):
        href = urljoin("https://www.bilibili.com", href)
    # 匹配 BV 号
    match = re.search(r"https://www\.bilibili\.com/video/(BV\w+)", href)
    if match:
        return f"https://www.bilibili.com/video/{match.group(1)}"
    return None


def extract_video_links(driver) -> set[str]:
    """从当前页面提取所有视频链接。"""
    links = set()
    for selector in VIDEO_LINK_SELECTORS:
        try:
            elements = driver.find_elements(By.CSS_SELECTOR, selector)
        except Exception:
            continue
        for el in elements:
            try:
                href = el.get_attribute("href")
            except StaleElementReferenceException:
                continue
            normalized = normalize_video_url(href)
            if normalized:
                links.add(normalized)
        if links:
            # 一旦某个选择器命中并拿到链接，就采用它
            break
    return links


def click_next_page(driver) -> bool:
    """尝试点击下一页按钮。返回是否成功。"""
    for by, locator, check_clickable in NEXT_PAGE_STRATEGIES:
        try:
            if check_clickable:
                btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((by, locator))
                )
            else:
                btn = driver.find_element(by, locator)
                # 手动判断是否禁用
                cls = btn.get_attribute("class") or ""
                if "disabled" in cls or "be-pager-disabled" in cls:
                    continue
        except (TimeoutException, NoSuchElementException):
            continue

        # 滚动到按钮位置并点击
        try:
            driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", btn)
            time.sleep(0.5)
            btn.click()
            return True
        except ElementClickInterceptedException:
            # 如果被遮挡，尝试 JS 点击
            try:
                driver.execute_script("arguments[0].click();", btn)
                return True
            except Exception:
                continue
        except Exception:
            continue
    return False


def wait_for_list_update(driver, old_links: set[str], timeout: int = 15) -> bool:
    """等待页面列表更新（通过判断链接集合是否变化）。"""
    end_time = time.time() + timeout
    while time.time() < end_time:
        time.sleep(1)
        new_links = extract_video_links(driver)
        if new_links != old_links:
            return True
    return False


def main():
    if DEBUG_SAVE_HTML:
        os.makedirs(DEBUG_DIR, exist_ok=True)

    driver = create_driver()
    all_links: set[str] = set()
    page_num = 1

    try:
        print(f"正在打开页面: {TARGET_URL}")
        driver.get(TARGET_URL)

        # 等待视频列表加载
        try:
            WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, LIST_CONTAINER_SELECTOR))
            )
        except TimeoutException:
            print("警告：未找到预期的视频列表容器，尝试继续...")

        # 额外等待 JS 渲染
        time.sleep(3)

        while True:
            print(f"\n===== 第 {page_num} 页 =====")

            # 提取本页链接
            page_links = extract_video_links(driver)
            new_links = page_links - all_links
            all_links.update(page_links)

            print(f"  本页提取到 {len(page_links)} 条链接，其中新链接 {len(new_links)} 条")
            if new_links:
                for link in sorted(new_links):
                    print(f"    {link}")

            if DEBUG_SAVE_HTML:
                html_path = os.path.join(DEBUG_DIR, f"page_{page_num}.html")
                with open(html_path, "w", encoding="utf-8") as f:
                    f.write(driver.page_source)
                print(f"  [DEBUG] 页面源码已保存到 {html_path}")

            # 检查最大页数限制
            if MAX_PAGES > 0 and page_num >= MAX_PAGES:
                print(f"已达到最大页数限制 {MAX_PAGES}，停止翻页。")
                break

            # 点击下一页
            print("  尝试点击下一页...")
            if not click_next_page(driver):
                print("  未找到可点击的下一页按钮，结束爬取。")
                break

            # 等待新内容加载
            print("  等待新页面加载...")
            updated = wait_for_list_update(driver, page_links, timeout=15)
            if not updated:
                print("  页面内容未发生变化，可能已到最后一页或加载失败。")
                # 再试一次提取，如果还是没有新内容则退出
                final_check = extract_video_links(driver)
                if final_check == page_links:
                    break

            page_num += 1
            time.sleep(MIN_WAIT_PER_PAGE)

    except KeyboardInterrupt:
        print("\n用户中断，正在保存已获取的数据...")
    finally:
        driver.quit()

    # 保存结果
    print(f"\n爬取完成，共获取 {len(all_links)} 条视频链接。")
    if all_links:
        with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
            for link in sorted(all_links):
                f.write(link + "\n")
        print(f"结果已保存到: {os.path.abspath(OUTPUT_FILE)}")
    else:
        print("未获取到任何链接，请检查页面结构或网络状况。")
        sys.exit(1)


if __name__ == "__main__":
    main()

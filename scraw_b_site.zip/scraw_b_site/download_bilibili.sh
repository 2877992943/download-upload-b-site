#!/bin/bash

TXT_FILE="bilibili_video_links.txt"
OUTPUT_DIR="/Users/ruiyang/Desktop/bilibili_downloads/data503"

# 创建输出目录（如果不存在）
mkdir -p "$OUTPUT_DIR"

# 逐行读取链接并下载
line_num=0
while IFS= read -r url; do
    # 跳过空行
    [ -z "$url" ] && continue

    line_num=$((line_num + 1))

    echo "[$line_num] 开始下载: $url"
    yt-dlp --merge-output-format mp4 "$url" -o "$OUTPUT_DIR/$line_num"

    if [ $? -eq 0 ]; then
        echo "[$line_num] 下载完成"
    else
        echo "[$line_num] 下载失败"
    fi

    echo "等待 10 秒后继续..."
    sleep 10
    echo ""
done < "$TXT_FILE"

echo "全部下载任务结束，共 $line_num 个视频"

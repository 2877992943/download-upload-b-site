#!/bin/bash
# Bilibili 批量下载脚本（逐条命令版）
# 输出目录: /Users/ruiyang/Desktop/bilibili_downloads

mkdir -p "/Users/ruiyang/Desktop/bilibili_downloads"

# ==================== 开始下载 ====================

# 1. 曲曲：长得帅会甜言蜜语，还是个时间管理大师
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1JZ9YBcEMN" -o "/Users/ruiyang/Desktop/bilibili_downloads/1"

# 2. 曲曲：超一线精英男择偶真相
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1yJDnBoErt" -o "/Users/ruiyang/Desktop/bilibili_downloads/2"

# 3. 曲曲：跟男人谈生意，先忘掉自己的性别
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1toDpBgERv" -o "/Users/ruiyang/Desktop/bilibili_downloads/3"

# 4. 曲曲：人要有翻篇的能力，承认自己的不完美，与自己和解
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1gMDnBKEHD" -o "/Users/ruiyang/Desktop/bilibili_downloads/4"

# 5. 曲曲：前期热情后期冷淡，女孩别因一段烂关系就动摇自己的人生
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1J99MBoEcX" -o "/Users/ruiyang/Desktop/bilibili_downloads/5"

# 6. 曲曲：读懂他行为背后的动机，他才会真正离不开你
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1HS9MB8Ecx" -o "/Users/ruiyang/Desktop/bilibili_downloads/6"

# 7. 曲曲：审美真的是未来顶级竞争力
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1fv9uBZEtn" -o "/Users/ruiyang/Desktop/bilibili_downloads/7"

# 8. 曲曲：人生没有既要又要，选对核心才是顶级智慧
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1nD9MBfEJ6" -o "/Users/ruiyang/Desktop/bilibili_downloads/8"

# 9. 曲曲：不美化未选择的路，你才能活得生机勃勃
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1Eq9uBtEns" -o "/Users/ruiyang/Desktop/bilibili_downloads/9"

# 10. 曲曲：为什么说带娃的女人，反而更容易被大佬疼一辈子？
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1PX9WBCEBZ" -o "/Users/ruiyang/Desktop/bilibili_downloads/10"

# 11. 曲曲：男人不能解决问题就没有任何的价值，优秀年轻女孩，别在烂人身上内耗自己
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1Y59sBtEiW" -o "/Users/ruiyang/Desktop/bilibili_downloads/11"

# 12. 曲曲：女人最好的状态，是在爱里重新爱上自己
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV18n9sBWEyw" -o "/Users/ruiyang/Desktop/bilibili_downloads/12"

# 13. 曲曲：30 + 美女别再图情绪价值了，情绪价值只有富婆才配，普通人先搞清楚站位
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1aL9sBoERL" -o "/Users/ruiyang/Desktop/bilibili_downloads/13"

# 14. 曲曲：年轻女孩早点明白，唯有自己才是自己的靠山
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1oT9sBAEZE" -o "/Users/ruiyang/Desktop/bilibili_downloads/14"

# 15. 曲曲：年轻美女一定要多补补脑子，不要轻易被男人画饼了
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1pA97BXEGD" -o "/Users/ruiyang/Desktop/bilibili_downloads/15"

# 16. 曲曲：别在临门一脚毁了所有！女生拿结果的核心思维
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1Up9VBpE1a" -o "/Users/ruiyang/Desktop/bilibili_downloads/16"

# 17. 曲曲：37 岁还在吃颜值老本，年龄到了就得认清楚现实
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1tcXBBDEjY" -o "/Users/ruiyang/Desktop/bilibili_downloads/17"

# 18. 曲曲：公婆控制欲强、老公没实权，想搞事业这条路怎么走？
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1r1XaB4EMx" -o "/Users/ruiyang/Desktop/bilibili_downloads/18"

# 19. 曲曲：遇到情绪极端的男人，快跑别内耗
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1h1XYBLEso" -o "/Users/ruiyang/Desktop/bilibili_downloads/19"

# 20. 曲曲：越怕失去越被动，女生在关系里千万别卑微
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1GaXSBFEog" -o "/Users/ruiyang/Desktop/bilibili_downloads/20"

# 21. 曲曲：爱情能保鲜一辈子，可我为什么非要那张证？扎心真相
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1MDXgBCErw" -o "/Users/ruiyang/Desktop/bilibili_downloads/21"

# 22. 曲曲：被前任女友挑衅该怎么回？19 岁的我说的话直接封神
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1igX8BkELy" -o "/Users/ruiyang/Desktop/bilibili_downloads/22"

# 23. 曲曲：底层女孩野心大筹码少？向上走时一定要这样保护好自己
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV11DXbBxE7N" -o "/Users/ruiyang/Desktop/bilibili_downloads/23"

# 24. 曲曲：我当了 10 年 “桌上的菜”，才打破原生家庭的天花板
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1XrXHBEEzV" -o "/Users/ruiyang/Desktop/bilibili_downloads/24"

# 25. 曲曲：男人对你的包容程度取决于你的价值高低
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV19zXHBSEXL" -o "/Users/ruiyang/Desktop/bilibili_downloads/25"

# 26. 曲曲：年轻女孩在保护自己的情况下多去谈恋爱，只要感受过，才知道什么样的人滋养你
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1FxXHB8Emk" -o "/Users/ruiyang/Desktop/bilibili_downloads/26"

# 27. 曲曲：女人一旦具备这个心态，你就再也没有内耗
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1LDXEB1EB3" -o "/Users/ruiyang/Desktop/bilibili_downloads/27"

# 28. 曲曲：不是婚姻这件事把你变遭的，是你一手造成的，能让自己变好的人永远只有自己
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1KBQzBHEJ2" -o "/Users/ruiyang/Desktop/bilibili_downloads/28"

# 29. 曲曲：越是下沉市场的女性，越是不要轻易结婚
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1VuQ9BqENn" -o "/Users/ruiyang/Desktop/bilibili_downloads/29"

# 30. 曲曲：要么学到，要么得到，最后变牛掰的人一定是你，最后的输家一定是对方
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1hAAMzPE1a" -o "/Users/ruiyang/Desktop/bilibili_downloads/30"

# 31. 曲曲：高段位女人从不听信男人的承诺，而是看他的行为，主动给承诺，走男人的路
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1akAMzqECS" -o "/Users/ruiyang/Desktop/bilibili_downloads/31"

# 32. 曲曲：向上社交别踩坑！教你一招看穿空有光环的人
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1xwAwz6EVe" -o "/Users/ruiyang/Desktop/bilibili_downloads/32"

# 33. 曲曲：表演出来的爱情会比真爱要舒适，真正的爱情带着压迫感的
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1ERAFz4EjG" -o "/Users/ruiyang/Desktop/bilibili_downloads/33"

# 34. 曲曲：成事的信念感：所有问题我都能解决，也只有我一个人能解决
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1VNAczSEVy" -o "/Users/ruiyang/Desktop/bilibili_downloads/34"

# 35. 曲曲：老男人的秋后算账，才是真正的狠招
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1XNByB3EiR" -o "/Users/ruiyang/Desktop/bilibili_downloads/35"

# 36. 曲曲：女人能自己搞钱搞学术，就别要废物男人当桥梁
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV188BaBiEpt" -o "/Users/ruiyang/Desktop/bilibili_downloads/36"

# 37. 曲曲：找婚恋一定要看对方的伴侣价值
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1zQBaBHEue" -o "/Users/ruiyang/Desktop/bilibili_downloads/37"

# 38. 曲曲：别等赚够钱再享受，我见过太多女生，赚了大钱却弄丢了快乐
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1r6BDBrE2e" -o "/Users/ruiyang/Desktop/bilibili_downloads/38"

# 39. 曲曲：别执念 “非他不可”！年轻女孩高嫁的正确路径
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1dgBDBwERC" -o "/Users/ruiyang/Desktop/bilibili_downloads/39"

# 40. 曲曲：没人会帮落魄的你！记住：高光时刻走 T 台，低谷期上战场
yt-dlp --merge-output-format mp4 "https://www.bilibili.com/video/BV1fFBUBcEaJ" -o "/Users/ruiyang/Desktop/bilibili_downloads/40"

# ==================== 全部命令执行完毕 ====================
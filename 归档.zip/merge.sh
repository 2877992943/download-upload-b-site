#####ffmpeg -i ./data/1.f30080.mp4 -i ./data/1.f30280.m4a -c:v copy -c:a copy -map 0:v:0 -map 1:a:0 ./data/output1.mp4



#!/bin/bash
DATA_DIR="./data"

for mp4 in "$DATA_DIR"/*.mp4; do
    [ -f "$mp4" ] || continue
    
    base=$(basename "$mp4")
    # 跳过已生成的 output 文件，避免自循环
    [[ "$base" == output* ]] && continue
    
    # 提取前缀数字（第一个点前的部分）
    prefix="${base%%.*}"
    
    # 查找同前缀的 m4a（取第一个匹配）
    m4a=$(ls "$DATA_DIR"/"$prefix".*.m4a 2>/dev/null | head -n 1)
    
    if [ -z "$m4a" ] || [ ! -f "$m4a" ]; then
        echo "⚠️  跳过 $base：未找到 ${prefix}.*.m4a"
        continue
    fi
    
    out="$DATA_DIR/output${prefix}.mp4"
    echo "▶️  合并: $base + $(basename "$m4a") -> output${prefix}.mp4"
    ffmpeg -i "$mp4" -i "$m4a" -c:v copy -c:a copy -map 0:v:0 -map 1:a:0 -y "$out"
done